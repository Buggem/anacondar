# anacondar
A Python terminal interface
